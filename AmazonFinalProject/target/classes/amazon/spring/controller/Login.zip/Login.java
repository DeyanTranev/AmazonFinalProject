package amazon.spring.controller;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

public class Login {

	
	@NotNull
	@Email
	private String email;
	
	@NotNull
	@Size(min = 6, max = 50)
	private String pass;
	
	public Login() {
		
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
	
}
